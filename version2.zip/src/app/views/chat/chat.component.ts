import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChatService, ChatAttachment, AttachmentKind } from './chat.service';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent {
  readonly chat = inject(ChatService);
  input = signal('');
  attachments = signal<ChatAttachment[]>([]);
  recording = signal(false);
  private rec?: MediaRecorder;
  private chunks: BlobPart[] = [];

  constructor() {
    if (!this.chat.activeId()) {
      if (this.chat.threads().length === 0) this.chat.newThread();
      else this.chat.setActive(this.chat.threads()[0].id);
    }
  }

  send() {
    const text = this.input().trim();
    const atts = this.attachments();
    if (!text && atts.length === 0) return;
    this.chat.addMessage(text, 'user', atts);
    this.input.set('');
    this.attachments.set([]);
    // Stubbed assistant reply
    setTimeout(() => this.chat.addMessage(`Echo: ${text || (atts.length ? `${atts.length} attachment(s)` : '')}`, 'assistant'), 300);
  }

  onFiles(files: FileList | File[]) {
    const list = Array.from(files as any as File[]);
    const mapped: ChatAttachment[] = list.map(f => {
      const kind: AttachmentKind = f.type.startsWith('image/') ? 'image' : f.type.startsWith('video/') ? 'video' : f.type.startsWith('audio/') ? 'audio' : 'file';
      return { id: crypto.randomUUID(), kind, name: f.name, mime: f.type || 'application/octet-stream', size: f.size, url: URL.createObjectURL(f) };
    });
    this.attachments.update(prev => [...prev, ...mapped]);
  }

  onFileInput(e: Event) {
    const input = e.target as HTMLInputElement;
    if (input.files && input.files.length) this.onFiles(input.files);
    input.value = '';
  }

  onDrop(e: DragEvent) {
    e.preventDefault();
    if (e.dataTransfer?.files?.length) this.onFiles(e.dataTransfer.files);
  }

  onDragOver(e: DragEvent) { e.preventDefault(); }

  removeAttachment(id: string) {
    this.attachments.update(prev => prev.filter(a => a.id !== id));
  }

  async startRecording() {
    if (this.recording()) return;
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.chunks = [];
    this.rec = new MediaRecorder(stream);
    this.rec.ondataavailable = e => { if (e.data && e.data.size) this.chunks.push(e.data); };
    this.rec.onstop = () => {
      const blob = new Blob(this.chunks, { type: 'audio/webm' });
      const file = new File([blob], `recording-${Date.now()}.webm`, { type: 'audio/webm' });
      this.onFiles([file]);
      stream.getTracks().forEach(t => t.stop());
      this.recording.set(false);
    };
    this.rec.start();
    this.recording.set(true);
  }

  stopRecording() {
    if (!this.rec) return;
    this.rec.stop();
  }
}
