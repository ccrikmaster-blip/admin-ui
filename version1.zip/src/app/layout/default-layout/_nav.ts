import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' }
  },
  {
    name: 'Chat',
    url: '/chat',
    iconComponent: { name: 'cil-speech' }
  },
  {
    name: 'Items',
    url: '/items',
    iconComponent: { name: 'cil-list' }
  }
];
