import { Component, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Item { id: number; name: string; category: string; image: string; }

@Component({
  selector: 'app-items',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.scss']
})
export class ItemsComponent {
  query = signal('');
  sortKey = signal<'name' | 'category'>('name');
  sortAsc = signal(true);

  items = signal<Item[]>([
    { id: 1, name: 'Alpha', category: 'A', image: 'https://picsum.photos/seed/a/80/80' },
    { id: 2, name: 'Beta', category: 'B', image: 'https://picsum.photos/seed/b/80/80' },
    { id: 3, name: 'Gamma', category: 'A', image: 'https://picsum.photos/seed/c/80/80' },
    { id: 4, name: 'Delta', category: 'C', image: 'https://picsum.photos/seed/d/80/80' }
  ]);

  filtered = computed(() => {
    const q = this.query().toLowerCase();
    const list = this.items().filter(i => !q || i.name.toLowerCase().includes(q) || i.category.toLowerCase().includes(q));
    const key = this.sortKey();
    const asc = this.sortAsc();
    return list.sort((a, b) => a[key].localeCompare(b[key]) * (asc ? 1 : -1));
  });

  setSort(key: 'name' | 'category') {
    if (this.sortKey() === key) this.sortAsc.set(!this.sortAsc());
    else { this.sortKey.set(key); this.sortAsc.set(true); }
  }
}
