import { Injectable, signal } from '@angular/core';

export interface ChatMessage { id: string; text: string; role: 'user' | 'assistant'; createdAt: number; }
export interface ChatThread { id: string; title: string; messages: ChatMessage[]; createdAt: number; }

@Injectable({ providedIn: 'root' })
export class ChatService {
  threads = signal<ChatThread[]>(this.#load());
  activeId = signal<string | null>(null);

  newThread(title = 'New Chat') {
    const t: ChatThread = { id: crypto.randomUUID(), title, messages: [], createdAt: Date.now() };
    this.threads.update(v => [t, ...v]);
    this.activeId.set(t.id);
    this.#persist();
  }

  setActive(id: string) {
    this.activeId.set(id);
  }

  rename(id: string, title: string) {
    this.threads.update(v => v.map(t => t.id === id ? { ...t, title } : t));
    this.#persist();
  }

  remove(id: string) {
    this.threads.update(v => v.filter(t => t.id !== id));
    if (this.activeId() === id) this.activeId.set(this.threads()[0]?.id ?? null);
    this.#persist();
  }

  addMessage(text: string, role: 'user' | 'assistant') {
    const id = this.activeId();
    if (!id) return;
    this.threads.update(v => v.map(t => t.id === id ? { ...t, messages: [...t.messages, { id: crypto.randomUUID(), text, role, createdAt: Date.now() }] } : t));
    this.#persist();
  }

  activeThread(): ChatThread | undefined {
    return this.threads().find(t => t.id === this.activeId());
  }

  #persist() {
    localStorage.setItem('tcs-genai-chat-threads', JSON.stringify(this.threads()));
    localStorage.setItem('tcs-genai-chat-active', this.activeId() ?? '');
  }

  #load(): ChatThread[] {
    try {
      const data = localStorage.getItem('tcs-genai-chat-threads');
      const parsed: ChatThread[] = data ? JSON.parse(data) : [];
      const active = localStorage.getItem('tcs-genai-chat-active');
      this.activeId.set(active || null);
      return parsed;
    } catch {
      return [];
    }
  }
}
