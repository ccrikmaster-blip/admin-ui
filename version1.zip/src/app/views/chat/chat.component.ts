import { Component, computed, effect, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChatService } from './chat.service';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent {
  readonly chat = inject(ChatService);
  input = signal('');

  constructor() {
    if (!this.chat.activeId()) {
      if (this.chat.threads().length === 0) this.chat.newThread();
      else this.chat.setActive(this.chat.threads()[0].id);
    }
  }

  send() {
    const text = this.input().trim();
    if (!text) return;
    this.chat.addMessage(text, 'user');
    this.input.set('');
    // Stubbed assistant reply
    setTimeout(() => this.chat.addMessage(`Echo: ${text}`, 'assistant'), 300);
  }
}
